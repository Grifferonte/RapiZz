create definer = root@localhost view menu as
select `rapizz`.`pizza`.`namePizza`                                                                 AS `namePizza`,
       `rapizz`.`pizza`.`basePrice`                                                                 AS `basePrice`,
       cast(concat('[', group_concat(json_quote(`i`.`nameIngredient`) separator ','), ']') as json) AS `ArrayIngredient`
from ((`rapizz`.`pizza` join `rapizz`.`compose` `c` on ((`rapizz`.`pizza`.`idPizza` = `c`.`idPizza`)))
         join `rapizz`.`ingredient` `i` on ((`c`.`idIngredient` = `i`.`idIngredient`)))
group by `rapizz`.`pizza`.`idPizza`;

